#' rciop
#'
#' @name rciop
#' @docType package

.onLoad <- function(libname, pkgname) {
	
	Sys.setenv(HADOOP_CMD="/usr/bin/hadoop")
	TMPDIR <<- Sys.getenv("TMPDIR")
	msg.trap <- capture.output(suppressMessages(library('XML')))
	msg.trap <- capture.output(suppressMessages(library('rhdfs')))
	msg.trap <- capture.output(suppressMessages(hdfs.init()))
	msg.trap <- capture.output(suppressMessages(library('RJSONIO')))
	msg.trap <- capture.output(suppressMessages(library('RCurl')))
}

get.webhdfs <- function(webhdfs.path) {
  if (!url.exists(webhdfs.path)) {
    return(NULL)
  }
  
  list.status.ncols <- 10
  
  webhdfs.json.file <- getURLContent(webhdfs.path)
  
  json <- fromJSON(webhdfs.json.file)  
  
  # unlist the json structure
  tmp <- unlist(json$FileStatuses[[1]])
  
  # convert the vector to matrix
  dim(tmp) <- c(list.status.ncols, length(tmp)/list.status.ncols)
  
  webhdfs.df <- t(tmp)
  colnames(webhdfs.df) <- c("accessTime","blockSize","group","length","modificationTime","owner","pathSuffix","permission","replication","type")
  
  return (as.data.frame(webhdfs.df))
}

get.runs <- function(sandbox.ip) {
  
  webhdfs.url <- paste("http://",sandbox.ip, ":50070/webhdfs/v1/tmp/sandbox/run?op=LISTSTATUS", sep="")
  
  return (get.webhdfs(webhdfs.url))  
  
}

get.nodes <- function (sandbox.ip, run.id) {
  webhdfs.url <- paste("http://",sandbox.ip, ":50070/webhdfs/v1/tmp/sandbox/run/", run.id,"?op=LISTSTATUS", sep="")
  tmp.df <- get.webhdfs(webhdfs.url)
  return (subset(tmp.df, type == "DIRECTORY" & !grepl("n-node", tmp.df$pathSuffix) & (pathSuffix != "_results" & pathSuffix != "clean" & pathSuffix != "prepare" & pathSuffix != "publish-results")))
}

get.results <- function (sandbox.ip, run.id) {
  webhdfs.url <- paste("http://", sandbox.ip, ":50070/webhdfs/v1/tmp/sandbox/run/", run.id,"/_results?op=LISTSTATUS", sep="")
  return (get.webhdfs(webhdfs.url))
}

read.ciop.result.csv <- function (sandbox.ip, run.id, csv.name, sep) {
  webhdfs.url <- paste("http://", sandbox.ip, ":50070/webhdfs/v1/tmp/sandbox/run/", run.id,"/_results/", csv.name, "?op=LISTSTATUS", sep="")
  
  if (!url.exists(webhdfs.url)) {
    csv <- NULL
  } else {
    csv <- read.csv(paste("http://", sandbox.ip, ":50070/webhdfs/v1/tmp/sandbox/run/", run.id,"/_results/", csv.name, "?op=OPEN", sep=""), sep=sep)
  }
  return (csv)
}

read.ciop.result.binary <- function (sandbox.ip, run.id, csv.name, binary.path) {
  webhdfs.url <- paste("http://", sandbox.ip, ":50070/webhdfs/v1/tmp/sandbox/run/", run.id,"/_results/", csv.name, "?op=LISTSTATUS", sep="")
  
  if (!url.exists(webhdfs.url)) {
    res <- NULL
  } else {
    res <- getBinaryURL(paste("http://", sandbox.ip, ":50070/webhdfs/v1/tmp/sandbox/run/", run.id,"/_results/", csv.name, "?op=OPEN", sep=""),followlocation=TRUE)
    #saving the raw data to disk
    binary.file <- file(binary.path,"wb")
    writeBin(res, binary.file)
    close(binary.file)
    res <- binary.path
  }
  return (res)
}

stopf = function(..., warning.length=8170L) {
  msg = sprintf(...)
  obj = simpleError(msg, call=sys.call(sys.parent()))
  old.opt = getOption("warning.length")
  on.exit(options(warning.length=old.opt))
  options(warning.length=warning.length)
  stop(obj)
}

collapse = function(x, sep=",") {
  paste(x, collapse=sep)
}

system3 = function(command, args = character(), stdout = "", stderr = "", wait=TRUE, ..., stop.on.exit.code=wait) {
  if (stop.on.exit.code && !wait)
    stopf("stop.on.exit.code is TRUE but wait is FALSE!")
  output = as.character(NA)
  exit.code = as.integer(NA)
  if (isTRUE(stdout) || isTRUE(stderr)) {
    wait = TRUE
    # here we wait anyway and output of cmd is returned
    ec = 0L
    suppressWarnings({
        withCallingHandlers({
            op = system2(command=command, args=args, stdout=stdout, stderr=stderr, wait=wait, ...)
          }, warning = function(w) {
            g = gregexpr("\\d+", w$message)[[1]]
            start = tail(g, 1L)
            len = tail(attr(g, "match.length"), 1)
            ec <<- as.integer(substr(w$message, start, start + len - 1))
          })
      })
  } else {
    ec = system2(command=command, args=args, stdout=stdout, stderr=stderr, wait=wait, ...)
  }
  if (wait) {
    if (isTRUE(stdout) || isTRUE(stderr))
      output = op
  }
  if (stop.on.exit.code && ec > 0L) {
    args = collapse(args, " ")
    if (length(output) == 0L)
      output = ""
    else
      output = collapse(output, "\n")
    stopf("Command: %s %s; exit code: %i; output: %s", command, args, ec, output)
  }
  list(exit.code=ec, output=output)
}

rciop.getparam <- function(param) {

param.name <- param

wf.root <- Sys.getenv('ciop_wf_run_root')
node <- Sys.getenv('ciop_job_nodeid')

wf.path <- paste(wf.root, "workflow-params.xml", sep="/")
wf.content <- hdfs.read.text.file(wf.path)
wp.xml<- xmlParse(wf.content)

par <- xpathSApply(wp.xml, paste("/workflow/node[@id='", node, "']/parameters/parameter[@id='", param.name, "']", sep=""), xmlValue)

return(par)
}

rciop.log <- function(type, message, proc='') {

type <- type 
msg <- message
if (proc=='') { proc <- "user process" }

out.msg <- paste(format(Sys.time(), format="%Y-%m-%dT%H:%M:%S"), "[", type, "][", proc, "] ", msg, sep="")

write(out.msg, stderr())
write(paste("reporter:status:", out.msg, sep=""), stderr())
}

rciop.copy <- function(url, target="./", uncompress=TRUE) {
  if (uncompress==FALSE) { opt <- "-U" } else { opt <- "" }
  args <- paste(opt, "-o", target, url, sep=" ") 
  res <- system3("ciop-copy", args, stdout=TRUE, wait=TRUE, stop.on.exit.code=FALSE)
  return(res)
}

rciop.publish <- function(path="./", recursive=FALSE, metalink=FALSE, mode="", driver="") {
  if (recursive) { opt <- "-r" } else { opt <- "" }
  if (metalink) { opt <- paste(opt, "-m", sep=" ")}
  if ( driver != "" ) { opt <- paste(opt, "-d", driver, sep=" ")}
  if ( mode == "silent" ) { 
    res <- system3("ciop-publish", "-s", input=path, stdout=TRUE, wait=TRUE, stop.on.exit.code=FALSE)
  } else {
    args <- paste(opt, path, sep=" ")
    res <- system3("ciop-publish", args, stdout=TRUE, wait=TRUE, stop.on.exit.code=FALSE)
   }
   return(res)
}


