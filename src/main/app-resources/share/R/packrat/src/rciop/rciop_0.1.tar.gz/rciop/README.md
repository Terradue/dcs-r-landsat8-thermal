rciop
=====

R package to access the developer cloud sandbox service results

Installation
-
Use the devtools package to do the installation

```
library("devtools")
install_github("rciop", "terradue")
```

Usage
-

The basic use of the rciop package is shown below with simple examples.

```
library("rciop")

# define the sandbox IP
sandbox.ip <- "10.16.10.30"

#get the run data frame
run.df <- get.runs (sandbox.ip)

# create a list with the run ids
run.list <- as.list(as.character(run.df$pathSuffix))

# create the list of the application DAG nodes
nodes.df <- get.nodes (sandbox.ip="10.16.10.30", run.id="0000001-130709163145111-oozie-oozi-W")

# get the results data frame
res.df <- get.results (sandbox.ip, "0000002-131010213504614-oozie-oozi-W")

# as a list
file.list <- as.list(as.character(res.df$pathSuffix))

# get the result csv as data frame
df <- read.ciop.result.csv(sandbox.ip=sandbox.ip, run.id="0000002-131010213504614-oozie-oozi-W", csv.name="occ_Carcharodon_carcharias.csv")
```
