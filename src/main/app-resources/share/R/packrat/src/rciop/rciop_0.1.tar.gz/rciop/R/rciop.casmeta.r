rciop.casmeta <- function(field, url) {
  args <- paste("-f '", field ,"' '", url, "'", sep="")
  res <- system3("ciop-casmeta", args, stdout=TRUE, wait=TRUE, stop.on.exit.code=FALSE)
  return(res)
}
